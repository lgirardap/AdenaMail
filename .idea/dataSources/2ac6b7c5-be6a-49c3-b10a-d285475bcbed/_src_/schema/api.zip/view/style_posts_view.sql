CREATE VIEW style_posts_view AS
  SELECT
    `api`.`posts`.`post_cd`            AS `post_cd`,
    `api`.`posts`.`post_type`          AS `post_type`,
    `api`.`posts`.`content`            AS `content`,
    `api`.`posts`.`published_datetime` AS `published_datetime`,
    `api`.`posts`.`image`              AS `image`,
    `api`.`posts`.`likes_count`        AS `likes_count`,
    `api`.`posts`.`comments_count`     AS `comments_count`,
    `api`.`style_posts`.`blog_cd`      AS `blog_cd`,
    `api`.`style_posts`.`text_content` AS `text_content`,
    `api`.`style_posts`.`views_count`  AS `views_count`,
    `api`.`users`.`user_cd`            AS `user_cd`
  FROM (((`api`.`posts`
    JOIN `api`.`style_posts` ON (((`api`.`posts`.`post_cd` = `api`.`style_posts`.`post_cd`) AND
                                  (`api`.`posts`.`post_type` = `api`.`style_posts`.`post_type`)))) JOIN `api`.`blogs`
      ON ((`api`.`blogs`.`blog_cd` = `api`.`style_posts`.`blog_cd`))) JOIN `api`.`users`
      ON ((`api`.`users`.`user_cd` = `api`.`blogs`.`user_cd`)))
  ORDER BY `api`.`posts`.`post_cd` DESC;
