CREATE VIEW blog_posts_view AS
  SELECT
    `c`.`post_cd`            AS `post_cd`,
    `c`.`post_type`          AS `post_type`,
    `c`.`title`              AS `title`,
    `c`.`content`            AS `content`,
    `c`.`published_datetime` AS `published_datetime`,
    `c`.`image`              AS `image`,
    `c`.`likes_count`        AS `likes_count`,
    `c`.`comments_count`     AS `comments_count`,
    `b`.`blog_cd`            AS `blog_cd`,
    `b`.`category_cd`        AS `category_cd`,
    `b`.`text_content`       AS `text_content`,
    `b`.`views_count`        AS `views_count`,
    `b`.`lang_abbr`          AS `lang_abbr`,
    `b`.`naver_blog_post_cd` AS `naver_blog_post_cd`,
    `a`.`user_cd`            AS `user_cd`
  FROM ((`api`.`blogs` `a` LEFT JOIN `api`.`blog_posts` `b` ON ((`b`.`blog_cd` = `a`.`blog_cd`))) LEFT JOIN
    `api`.`posts` `c` ON ((`c`.`post_cd` = `b`.`post_cd`)))
  WHERE (`a`.`is_active` = 'Y');
